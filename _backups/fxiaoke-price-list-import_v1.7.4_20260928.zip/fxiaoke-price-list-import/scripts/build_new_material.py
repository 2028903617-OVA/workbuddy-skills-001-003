#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""特别分支：批量新增物料 —— 由「对方型号」生成 规格型号(F) 与 金蝶物料名(G)。

适用：价目表大调整 / 一次性新增大量型号 / 源表型号在销客里不存在需要新建。
只读写本地 xlsx，不联网、不写纷享销客。

用法:
  python build_new_material.py --source <源表.xlsx> --sheet <sheet名>
      [--col-brand 1] [--col-industry 3] [--col-model 5] [--col-f 6] [--col-g 7]
      [--product-snapshot <产品快照.xlsx>]
      [--extra-sample-sheet "已新增价目表明细"] [--extra-sample-col 5]
      [--outdir <输出目录>] [--dry-run]

输出:
  <outdir>/<源表名>_已补FG_<YYYYMMDD>.xlsx   源表副本（F/G 已填）
  <outdir>/待确认清单_<YYYYMMDD>.xlsx        低置信行
  stdout 摘要 JSON
"""
import argparse
import datetime
import json
import os
import re
import sys
import difflib
from collections import Counter, defaultdict

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill
except ImportError:  # pragma: no cover
    print(json.dumps({"error": "openpyxl 未安装"}, ensure_ascii=False))
    sys.exit(2)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_import import BRAND_KEYWORDS  # noqa: E402

# ---------------------------------------------------------------- 常量
# 品牌名单只维护一份，能力 3 直接复用能力 1 的词表。
# 此前这里另存了一份 16 个品牌的清单，漏掉大金等 38 个品牌，
# 后果是产品快照里的大金产品全部进不了样本库、大金型号推断不出品项（物料名整列空白且不报错）。
BRANDS = sorted(set(BRAND_KEYWORDS) | {"添可"}, key=len, reverse=True)

IND_KEY = {
    "冰箱": ["冰箱", "冰吧", "酒柜", "冰柜"],
    "洗护": ["洗衣机", "洗干", "干衣机", "衣物护理", "洗烘"],
    "电视机": ["平板电视", "电视"],
    "厨房大电": ["洗碗机", "蒸烤", "烤箱", "蒸箱", "微波炉", "油烟机", "灶具", "消毒柜", "集成灶"],
    "居家清洁": ["扫地机器人", "洗地机", "吸尘", "扫地", "擦窗"],
    "空调": ["空调", "挂机", "柜机", "风管机", "多联"],
    "热水器": ["热水器", "采暖炉"],
    "水健康": ["净水", "管线机", "软水", "前置"],
}

# 品牌前缀：'/' 后面必须紧跟中文，避免误伤 KFR-72LW/U61-1、H1210-MBLNE/QT98TU1
BRAND_PREFIX = re.compile(r"^\s*[A-Za-z][A-Za-z\.\-]*/[一-龥]+\s*")
PROMO = [r"\d+\s*英寸", r"\d+\s*吋", r"官方标配", r"大屏护眼", r"世界杯",
         r"更护眼的家庭影院", r"&nbsp;", r"【新品】", r"2026款"]
TV_COLOR = ["流砂锖", "枪色", "钛金灰", "曜石黑", "钢琴黑", "太空灰", "星空灰"]
TV_BRAND_WORDS = ["海信RGB激光电视", "海信激光电视", "海信", "创维", "TCL", "电视"]
# 电视型号码后面的系列后缀词（无数字，正则抽码时会漏掉，需补回）
SERIES_WORD = re.compile(r"^(Ultra|Pro|Max|Plus|Mini|SE|X)$", re.I)
# 型号码：允许数字开头（75E8S / 100L7QR）
TAIL = re.compile(r"[A-Za-z0-9][A-Za-z0-9][A-Za-z0-9\-\.\(\)\+/]{3,}\s*$")
# 品项尾部脏值：CE / CZ / CG / CEC 等系列码（2-4 个大写字母），如「滚筒洗衣机CEC」
JUNK_ITEM = re.compile(r"[A-Z]{2,4}\s*$")
BAD_ITEM = re.compile(r"IOT|智能物联|赠品|样机|空机$|套装$")
AC_P = {"25": "1", "26": "1", "32": "1.5", "33": "1.5", "35": "1.5", "36": "1.5",
        "40": "2", "45": "2", "46": "2", "50": "2", "51": "2", "60": "3", "61": "3",
        "71": "3", "72": "3", "73": "3", "88": "4", "120": "5"}


# ---------------------------------------------------------------- 基础工具
def industry_of(item):
    for ind, kws in IND_KEY.items():
        if any(k in item for k in kws):
            return ind
    return "其他"


def lcp(a, b):
    n = 0
    for x, y in zip(a.lower(), b.lower()):
        if x != y:
            break
        n += 1
    return n


def parse_name(name, brands=None):
    """'容声对开门冰箱BCD-606WKK1FPGZA' -> (容声, 对开门冰箱, BCD-606WKK1FPGZA)"""
    n = str(name or "").strip()
    if not n:
        return None
    br = None
    for b in (brands or BRANDS):
        if n.startswith(b):
            br, rest = b, n[len(b):]
            break
    if not br:
        return None
    m = TAIL.search(rest)
    if not m:
        return None
    item, code = rest[:m.start()].strip(), m.group(0).strip()
    item = re.sub(r"\d+\s*$", "", item).strip()   # 平板电视75 -> 平板电视
    item = JUNK_ITEM.sub("", item).strip()        # 滚筒洗衣机CE -> 滚筒洗衣机
    if not item:
        return None
    return (br, item, code)


def load_products(path):
    """产品快照 -> list of {name, mat, spec}"""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    hdr = [str(h).strip() if h is not None else ""
           for h in next(ws.iter_rows(min_row=1, max_row=1, values_only=True))]

    def ix(name):
        return hdr.index(name) if name in hdr else None
    i_n, i_m, i_s = ix("产品名称（必填）"), ix("物料名称"), ix("型号规格")
    out = []
    for r in ws.iter_rows(min_row=2, max_row=ws.max_row, values_only=True):
        def g(i):
            return (str(r[i]).strip() if i is not None and i < len(r) and r[i] is not None else "")
        if not g(i_n):
            continue
        out.append({"name": g(i_n), "mat": g(i_m), "spec": g(i_s)})
    wb.close()
    return out


def build_lib(products, extra_names=None):
    """-> {品牌: [(型号码, 品项), ...]}"""
    lib = defaultdict(list)
    for p in products:
        s = parse_name(p.get("name"))
        if s:
            lib[s[0]].append((s[2], s[1]))
    for n in (extra_names or []):
        s = parse_name(n)
        if s:
            lib[s[0]].append((s[2], s[1]))
    return lib


# ---------------------------------------------------------------- 清洗
def clean_model(e, industry=None, brand=None):
    """E 列 -> 规格型号 F（通用，非电视）"""
    s = str(e or "").replace("&nbsp;", " ").replace("\xa0", " ").strip()
    s = re.sub(r"^\s*【新品】\s*", "", s)
    s = BRAND_PREFIX.sub("", s)
    # 型号里自带品牌名但没有「英文/中文」分隔符时（如「大金FFDP90BA」），BRAND_PREFIX 够不着，
    # 按品牌列再剥一次。不剥的话 compose_g 会以为型号已带品牌而省掉品牌前缀，
    # 把品项顶到最前面，拼出「内机大金FFDP90BA」这种错误顺序。
    b = str(brand or "").strip()
    if b and s.startswith(b) and len(s) > len(b):
        s = s[len(b):].strip()
    s = re.sub(r"^\s*【新品】\s*", "", s)
    for pat in PROMO:
        s = re.sub(pat, "", s)
    s = re.sub(r"\s{2,}", " ", s).strip()
    # 只在「字母+连字符」后合空格：MR- 449 -> MR-449；不能误伤 芙万 Artist 50S
    s = re.sub(r"([A-Za-z]-)\s+(\d)", r"\1\2", s)
    half = len(s) // 2
    if len(s) > 8 and half > 3 and s[:half].strip() == s[len(s) - half:].strip():
        s = s[:half].strip()                                # 重复片段去重
    return s


def tv_model(e):
    """电视机专用：抽型号码，抽不到就退回清洗后的中文系列名"""
    s = re.sub(r"^\s*【新品】\s*", "", str(e or "")).replace("&nbsp;", " ").replace("\xa0", " ")
    s = BRAND_PREFIX.sub("", s)
    for pat in PROMO:
        s = re.sub(pat, "", s)
    for b in TV_BRAND_WORDS:
        s = s.replace(b, " ")
    for c in TV_COLOR:
        s = s.replace(c, " ")
    s = re.sub(r"\s{2,}", " ", s).strip()
    codes = [x for x in re.findall(r"[A-Za-z0-9][A-Za-z0-9\-]{4,}", s) if re.search(r"\d", x)]
    if codes:
        best = sorted(codes, key=len, reverse=True)[0]
        # 紧随型号码的系列后缀要保留：115Q10M Ultra / 98Q10M Pro（不能只留 115Q10M）
        after = s.split(best, 1)[1].split() if best in s else []
        if after and SERIES_WORD.match(after[0]):
            return "%s %s" % (best, after[0])
        return best
    return s


def primary_code(spec):
    toks = [x for x in re.findall(r"[A-Za-z0-9][A-Za-z0-9\-\.\(\)\+/]{3,}", spec)
            if re.search(r"\d", x)]
    if not toks:
        return spec[:14]
    return sorted(toks, key=len, reverse=True)[0].split("+")[0]


# ---------------------------------------------------------------- 品项推断
def ac_item(code):
    """KFR-35GW -> 1.5匹变频挂机"""
    m = re.search(r"KFR-(\d+)(GW|LW)", code, re.I)
    if not m:
        return "", 0.0, ""
    num, form = m.group(1), m.group(2).upper()
    pin = AC_P.get(num, "")
    typ = "变频挂机" if form == "GW" else "变频柜机"
    if not pin:
        return "", 0.0, ""
    return "%s匹%s" % (pin, typ), 0.7, "空调型号推导"


def guess_item(brand, code, industry, lib):
    """-> (品项, 置信度, 来源)"""
    cands = lib.get(brand, [])
    best = (0, 0.0, "")
    for c, item in cands:
        l = lcp(code, c)
        rt = difflib.SequenceMatcher(None, code.lower(), c.lower()).ratio()
        if (l, rt) > (best[0], best[1]):
            best = (l, rt, item)
    l, rt, item = best
    if item and industry and industry_of(item) != industry:
        # 行业不符：借来的品项直接丢弃（不能再走 型号相似 高置信返回），改走兜底
        item, l, rt = "", 0, 0.0
    if item and l >= 5:
        return item, round(min(0.99, 0.45 + l / 22.0 + rt / 5), 2), "最相近型号"
    if item and rt >= 0.75:
        return item, round(rt, 2), "型号相似"
    if industry == "空调":
        it, cf, src = ac_item(code)
        if it:
            return it, cf, src
    # 同品牌同行业众数 优先于 行业兜底（众数更贴近该品牌实际叫法）
    ctr = Counter(it for _, it in cands if industry_of(it) == industry)
    if ctr:
        it, v = ctr.most_common(1)[0]
        return it, round(v / sum(ctr.values()), 2), "行业众数 %d/%d" % (v, sum(ctr.values()))
    if industry == "水健康":
        return "净水机", 0.3, "水健康兜底"
    if industry == "热水器":
        return "燃气热水器", 0.3, "热水器兜底"
    return "", 0.0, "无可用样本"


def fix_item(item, industry, code, brand):
    """脏值过滤 + 西门子厨电型号特征"""
    if item and BAD_ITEM.search(item):
        item = ""
    if not item:
        if industry == "热水器":
            item = "燃气热水器"
        elif industry == "水健康":
            item = "净水机"
    if industry == "厨房大电" and brand == "西门子":
        if code.upper().startswith("CXW"):
            item = "国产欧式油烟机"
        elif "蒸烤" in code or re.match(r"^CS\d", code, re.I):
            item = "国产嵌入式蒸烤一体机"
    return item


def compose_g(brand, item, spec):
    """G = 品牌 + 品项 + 规格型号；spec 已含「品牌+品项」或已含品牌时不重复"""
    if not (item and spec):
        return ""
    if brand and brand in spec and item in spec:
        return spec                      # spec 已含 品牌+品项（如 海信激光电视星光S1）
    head = "" if spec.startswith(brand) else brand
    return "%s%s%s" % (head, item, spec)


# ---------------------------------------------------------------- 主流程
def process_rows(rows, lib):
    """rows: [{row, brand, industry, E}] -> 追加 F/G/item/conf/src"""
    out = []
    for r in rows:
        industry = r["industry"]
        if industry == "电视机":
            spec = tv_model(r["E"])
            item = "激光电视" if "激光电视" in str(r["E"]) else "平板电视"
            conf, src = 0.75, "电视规则"
        else:
            spec = clean_model(r["E"], industry, r.get("brand"))
            item, conf, src = guess_item(r["brand"], primary_code(spec), industry, lib)
            item = fix_item(item, industry, primary_code(spec), r["brand"])
        if not spec:
            conf = 0.0
        out.append(dict(r, F=spec, G=compose_g(r["brand"], item, spec),
                        item=item, conf=conf, src=src))
    return out


# ---------------------------------------------------------------- 列定位（按表头语义，不写死列字母）
# 源表格式每次都可能不同：表名、表头行、列名、有没有预留输出列都会变。
# 一律按语义定位；结果列定位不到就追加新列，绝不动原有列。
COL_SEMANTICS = {
    "model":    ["型号标题", "商品名称", "货品名称", "产品官方名称及型号", "型号"],
    "short":    ["型号简称", "简称"],
    "brand":    ["品牌", "品牌系"],
    "industry": ["行业", "品类", "产品大类", "大类"],
    "spec":     ["规格型号", "规格"],
    "material": ["物料名称", "金蝶物料名", "内部物料名称", "我方物料名称"],
}
SHORT_KW = 2          # 长度 ≤ 该值的词只允许整格相等，避免「产品」误命中「产品大类」
SHEET_HINTS = ("货品", "主推", "规划", "物料", "新增", "商品", "型号", "价目")


def norm_cell(v):
    """表头归一化：去首尾空白 + 去掉括号段（（必填）、（单列）、【…】…）。"""
    s = "" if v is None else str(v)
    s = re.sub(r"[（(【\[][^）)】\]]*[）)】\]]", "", s)
    return s.strip()


def _hit(cell, kw):
    c = norm_cell(cell)
    if not c:
        return False
    if c == kw:
        return True
    return len(kw) > SHORT_KW and kw in c


def header_of(ws, r):
    return [ws.cell(row=r, column=c).value for c in range(1, ws.max_column + 1)]


def row_hits(row):
    hits = set()
    for key, kws in COL_SEMANTICS.items():
        for c in row:
            if any(_hit(c, kw) for kw in kws):
                hits.add(key)
                break
    return hits


def find_header_row(ws, scan=8):
    """表头行 = 前 scan 行里命中语义数最多、且含型号类列的那一行。"""
    best, best_n = 1, -1
    for r in range(1, min(scan, ws.max_row) + 1):
        h = row_hits(header_of(ws, r))
        if len(h) > best_n and "model" in h:
            best, best_n = r, len(h)
    return best


def sheet_candidates(wb):
    """有表头语义的 sheet。跳过 hidden；
    SheetN 名不硬跳（真数据也可能装在唯一一个 Sheet1 里，实测踩过），
    但排在非 SheetN 名候选之后——只在没得选时才用。"""
    named, sheetn = [], []
    for sn in wb.sheetnames:
        if sn.lower().startswith("hidden"):
            continue
        if "model" in row_hits(header_of(wb[sn], find_header_row(wb[sn]))):
            (sheetn if re.fullmatch(r"[Ss]heet\d+", sn) else named).append(sn)
    return named or sheetn


def pick_sheet(wb):
    cands = sheet_candidates(wb)
    if not cands:
        return None
    hinted = [s for s in cands if any(h in s for h in SHEET_HINTS)]
    return (hinted or cands)[-1]


def _find_col(hdr, kws):
    for kw in kws:                                   # 一轮：整格相等
        for i, c in enumerate(hdr, start=1):
            if norm_cell(c) == kw:
                return i
    for kw in kws:                                   # 二轮：包含（仅长词）
        if len(kw) <= SHORT_KW:
            continue
        for i, c in enumerate(hdr, start=1):
            nc = norm_cell(c)
            if nc and kw in nc:
                return i
    return None


def resolve_columns(ws, hdr_row, args):
    """返回 (列位置 dict, 需要追加的列名 list)。显式 --col-* 优先于语义定位。"""
    hdr = header_of(ws, hdr_row)
    explicit = {"brand": args.col_brand, "industry": args.col_industry,
                "model": args.col_model, "spec": args.col_f, "material": args.col_g}
    cols = {}
    for key, kws in COL_SEMANTICS.items():
        cols[key] = explicit.get(key) or _find_col(hdr, kws)
    appended = [k for k in ("spec", "material") if not cols.get(k)]
    return cols, appended


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--sheet", default=None,
                    help="不传则按 sheet 名线索 + 表头语义自动选择，并在摘要里回报所选 sheet")
    ap.add_argument("--col-brand", type=int, default=None)
    ap.add_argument("--col-industry", type=int, default=None)
    ap.add_argument("--col-model", type=int, default=None,
                    help="对方型号标题列（不传则按表头语义自动定位）")
    ap.add_argument("--col-f", type=int, default=None, help="规格型号输出列（不传则自动定位或追加）")
    ap.add_argument("--col-g", type=int, default=None, help="物料名称输出列（不传则自动定位或追加）")
    ap.add_argument("--header-row", type=int, default=None, help="不传则自动识别表头行")
    ap.add_argument("--product-snapshot", default=None)
    ap.add_argument("--downloads", default=r"D:\Backup\Downloads")
    ap.add_argument("--extra-sample-sheet", default=None)
    ap.add_argument("--extra-sample-col", type=int, default=None)
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.source):
        print(json.dumps({"error": "源表不存在: %s" % args.source}, ensure_ascii=False))
        sys.exit(2)

    wb = openpyxl.load_workbook(args.source, data_only=True)
    sheet_name = args.sheet or pick_sheet(wb)
    if sheet_name is None or sheet_name not in wb.sheetnames:
        print(json.dumps({"error": "定位不到数据 sheet（现有: %s），请用 --sheet 指定"
                          % wb.sheetnames}, ensure_ascii=False))
        sys.exit(2)
    ws = wb[sheet_name]

    hdr_row = args.header_row or find_header_row(ws)
    cols, appended = resolve_columns(ws, hdr_row, args)

    if not cols.get("model"):
        # 不猜解析源：金蝶供货价表这类已经规范化的内部表（只有 物料名称+规格型号，两列都正确）
        # 拿「物料名称」当解析源会把整串物料名写进规格型号列，实测 295 行被改坏。
        # 能力 3 的输入是**对方型号标题清单**，没有型号类列就说明不是这类输入，停下来问清楚。
        names = ", ".join(str(ws.cell(hdr_row, c).value) for c in
                          range(1, min(ws.max_column, 12) + 1)
                          if ws.cell(hdr_row, c).value is not None)
        print(json.dumps({"error": "定位不到「型号标题」类列，无法生成物料名。"
                                   "能力3 的输入是对方型号标题清单；"
                                   "若本表已有规范的物料名称/规格型号列，请直接用，不必生成。"
                                   "确要指定解析列请用 --col-model <列号>。"
                                   "表头行第 %d 行的列名：%s" % (hdr_row, names)},
                         ensure_ascii=False))
        sys.exit(2)
    # 输出列若不存在则追加（结果写在新列，不动原有列）
    out_f, out_g = cols.get("spec"), cols.get("material")
    next_col = ws.max_column
    if out_f is None:
        next_col += 1
        ws.cell(row=hdr_row, column=next_col).value = "规格型号"
        out_f = next_col
    if out_g is None:
        next_col += 1
        ws.cell(row=hdr_row, column=next_col).value = "物料名称"
        out_g = next_col

    # 样本库
    snap = args.product_snapshot
    if not snap:
        import glob as _g
        cands = sorted(_g.glob(os.path.join(args.downloads, "产品对象导出结果_*.xlsx")), reverse=True)
        snap = next((f for f in cands if not os.path.basename(f).startswith("~$")), None)
    products = load_products(snap) if snap else []
    extra = []
    if args.extra_sample_sheet and args.extra_sample_sheet in wb.sheetnames:
        ex_col = args.extra_sample_col or cols.get("material") or cols["model"]
        for r in wb[args.extra_sample_sheet].iter_rows(min_row=hdr_row + 1, values_only=True):
            v = r[ex_col - 1] if len(r) >= ex_col else None
            if v:
                extra.append(str(v))
    lib = build_lib(products, extra)

    def cell(ridx, key):
        ci = cols.get(key)
        return ws.cell(row=ridx, column=ci).value if ci else None

    rows = []
    for ridx in range(hdr_row + 1, ws.max_row + 1):
        e = cell(ridx, "model")
        d = cell(ridx, "short")
        if not str(e or "").strip() and not str(d or "").strip():
            continue
        raw_brand = str(cell(ridx, "brand") or "")
        rows.append({"row": ridx,
                     "brand": raw_brand.split("/")[-1].strip(),
                     "industry": str(cell(ridx, "industry") or "").strip(),
                     "E": str(e or "")})
    res = process_rows(rows, lib)

    today = datetime.date.today().strftime("%Y%m%d")
    outdir = args.outdir or os.path.dirname(os.path.abspath(args.source))
    os.makedirs(outdir, exist_ok=True)
    n_empty = sum(1 for r in res if not r["F"] or not r["G"])
    n_low = sum(1 for r in res if r["conf"] < 0.7)

    if not args.dry_run:
        for r in res:
            # 空值不覆盖：生成失败时保留源表已有内容（解析源可能就是输出列本身，
            # 拿空结果盖掉原有正确物料名是破坏性操作）
            if r["F"]:
                ws.cell(row=r["row"], column=out_f).value = r["F"]
            if r["G"]:
                ws.cell(row=r["row"], column=out_g).value = r["G"]
        base = os.path.splitext(os.path.basename(args.source))[0]
        p1 = os.path.join(outdir, "%s_已补规格型号与物料名_%s.xlsx" % (base, today))
        wb.save(p1)

        wb2 = openpyxl.Workbook()
        ws2 = wb2.active
        ws2.title = "待确认清单"
        ws2.append(["低置信(置信<0.7)共 %d 行，请人工复核品项" % n_low])
        ws2.append(["行号", "品牌", "行业", "对方型号标题", "规格型号", "我方物料名称",
                    "品项", "来源", "置信"])
        for r in res:
            if r["conf"] < 0.7:
                ws2.append([r["row"], r["brand"], r["industry"], r["E"], r["F"], r["G"],
                            r["item"], r["src"], r["conf"]])
        for i in range(1, 10):
            c = ws2.cell(row=2, column=i)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="2F5597")
        for i, w in enumerate([8, 12, 12, 40, 34, 44, 20, 18, 10], start=1):
            ws2.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
        p2 = os.path.join(outdir, "待确认清单_%s.xlsx" % today)
        wb2.save(p2)
    else:
        p1 = p2 = "(dry-run 未写文件)"

    print(json.dumps({
        "sheet": sheet_name, "sheet_auto": args.sheet is None,
        "表头行": hdr_row, "列位置": cols,
        "追加列": appended,
        "数据行": len(res),
        "样本库": sum(len(v) for v in lib.values()), "品牌数": len(lib),
        "两列有空值": n_empty, "低置信": n_low,
        "品项来源": dict(Counter(r["src"] for r in res).most_common()),
        "files": [p1, p2],
    }, ensure_ascii=False, indent=2))
    wb.close()


if __name__ == "__main__":
    main()
