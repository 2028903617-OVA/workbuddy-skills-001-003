#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""环境只读检查：Python 版本、openpyxl、两类快照可发现性。

输出 JSON: {"status": "ready|partial|needs_setup", "checks": [...]}
只读取状态，不安装、不联网、不修改任何配置。
"""
import glob
import json
import os
import sys

DOWNLOADS = r"D:\Backup\Downloads"


def _header_and_row2(path):
    """读表头与第 2 行。read_only 下 dimension 损坏的导出文件会只读到 1 列
    （实测 09-21 产品快照 max_column=1），列数 < 3 时回退非只读模式。"""
    import openpyxl
    for read_only in (True, False):
        try:
            wb = openpyxl.load_workbook(path, read_only=read_only, data_only=True)
            ws = wb[wb.sheetnames[0]]
            hdr = row2 = None
            for row in ws.iter_rows(min_row=1, max_row=1, values_only=True):
                hdr = [str(h) if h is not None else "" for h in row]
            for row in ws.iter_rows(min_row=2, max_row=2, values_only=True):
                row2 = list(row)
            wb.close()
            if hdr and len(hdr) >= 3:
                return hdr, row2
        except Exception:
            continue
    return None, None


def find_snapshot(pattern, required_cols):
    files = sorted(glob.glob(os.path.join(DOWNLOADS, pattern)), reverse=True)
    for f in files:
        if os.path.basename(f).startswith("~$"):
            continue
        hdr, row2 = _header_and_row2(f)
        if hdr is None:
            continue
        ok = all(c in hdr for c in required_cols)
        if ok and (not row2 or row2[0] is None or str(row2[0]).strip() == ""):
            ok = False
        if ok:
            return f
    return None


def main():
    checks = []

    ver = sys.version_info
    checks.append({"id": "python", "ok": ver >= (3, 10),
                   "detail": "Python %d.%d.%d" % (ver.major, ver.minor, ver.micro)})

    openpyxl_ok, openpyxl_detail = False, "未安装"
    try:
        import openpyxl
        openpyxl_ok = True
        openpyxl_detail = "openpyxl %s" % openpyxl.__version__
    except ImportError:
        pass
    checks.append({"id": "openpyxl", "ok": openpyxl_ok, "detail": openpyxl_detail})

    prod = find_snapshot("产品对象导出结果_*.xlsx", ["产品名称（必填）", "物料名称"])
    checks.append({"id": "product-snapshot", "ok": prod is not None,
                   "detail": prod or "Downloads 下找不到含必需列且有数据的产品对象导出"})

    det = find_snapshot("价目表明细对象导出结果_*.xlsx", ["产品（必填）", "价目表（必填）"])
    checks.append({"id": "detail-snapshot", "ok": det is not None,
                   "detail": det or "Downloads 下找不到含必需列且有数据的价目表明细导出"})

    if not openpyxl_ok:
        status = "needs_setup"
    elif not ver >= (3, 10):
        status = "needs_setup"
    elif prod is None and det is None:
        status = "partial"
    elif prod is None or det is None:
        status = "partial"
    else:
        status = "ready"

    print(json.dumps({"status": status, "checks": checks}, ensure_ascii=False, indent=2))
    sys.exit(0 if status in ("ready", "partial") else 1)


if __name__ == "__main__":
    main()
